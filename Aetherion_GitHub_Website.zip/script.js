const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
menuToggle.addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => nav.classList.remove('open')));
document.getElementById('beginButton').addEventListener('click', () => {
  const note = document.getElementById('prototypeNote');
  note.textContent = 'The Aetherion 3D game is in development. This website is its official world and project landing page.';
  note.classList.add('highlight');
});
