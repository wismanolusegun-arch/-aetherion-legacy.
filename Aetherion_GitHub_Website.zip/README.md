# Aetherion: The Creator's Legacy

A responsive static website for the Aetherion fantasy anime RPG project.

## Preview locally
Open `index.html` in a browser. No build tools or server are required.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a **public** repository named `aetherion-legacy`.
2. Upload `index.html`, `style.css`, `script.js`, and this `README.md` to the repository's root (not inside another folder).
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then press **Save**.
6. Wait for GitHub Pages to publish. Your site address will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/aetherion-legacy/`

For a personal site repository named `YOUR-GITHUB-USERNAME.github.io`, the address is:
`https://YOUR-GITHUB-USERNAME.github.io/`

## Notes
- GitHub Pages hosting is free for public repositories.
- GitHub Pages provides a free `github.io` web address. A custom domain name is optional and usually costs money.
- This is the Aetherion website/landing page. The full playable 3D RPG, character models, quests and combat systems are separate game-development work.
